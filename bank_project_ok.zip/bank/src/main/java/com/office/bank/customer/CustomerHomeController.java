package com.office.bank.customer;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/customer")
public class CustomerHomeController {

	@RequestMapping({"", "/"})
	public String home() {
		String nextPage = "customer/home";
		return nextPage;
	}
	
}
