package com.office.bank.customer.member;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.office.bank.transaction.AccountVo;
import com.office.bank.transaction.ExchangeVo;
import com.office.bank.transaction.LoanVo;
import com.office.bank.transaction.NoticeVo;
import com.office.bank.transaction.TransactionVo;

@Component
public class CustomerMemberDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	private SqlSession sqlSession;

	// ���̵�Ȯ��
	public boolean isCustomerMember(String customer_id) throws DataAccessException {
		int result = 0;
		result = sqlSession.selectOne("mapper.customerMember.idCheck", customer_id);
		return result > 0 ? true : false;
	}

	// ȸ������
	public int insertCustomer(CustomerMemberVo customerMemberVo) throws DataAccessException {
		int result = -1;
		customerMemberVo.setCustomer_pw(passwordEncoder.encode(customerMemberVo.getCustomer_pw()));
		result = sqlSession.insert("mapper.customerMember.insertCustomerAccount", customerMemberVo);
		return result;
	}

	// ���̵� ��й�ȣ ��Ī ���Ѽ� �α���
	public CustomerMemberVo selectAdmin(CustomerMemberVo customerMemberVo) throws DataAccessException {
		System.out.println(customerMemberVo+"디에오");
		List<CustomerMemberVo> customerMemberVos = new ArrayList<CustomerMemberVo>();
		customerMemberVos = sqlSession.selectList("mapper.customerMember.selectCustomer",
				customerMemberVo.getCustomer_id());
		System.out.println(customerMemberVos+"if전");
		if (!passwordEncoder.matches(customerMemberVo.getCustomer_pw(), customerMemberVos.get(0).getCustomer_pw())) {
			customerMemberVos.clear();
		}
		System.out.println(customerMemberVos+"디에오사이즈");
		return customerMemberVos.size() > 0 ? customerMemberVos.get(0) : null;
	}

	public CustomerMemberVo selectAdmins(CustomerMemberVo customerMemberVo) throws DataAccessException {
		List<CustomerMemberVo> customerMemberVos = new ArrayList<CustomerMemberVo>();

		customerMemberVos = sqlSession.selectList("mapper.customerMember.selectCustomerFind", customerMemberVo);
		return customerMemberVos.size() > 0 ? customerMemberVos.get(0) : null;
	}

	public int updatePassword(String customer_id, String newPassword) {

		String sql = "UPDATE customer SET " + "customer_pw = ?" + "WHERE customer_id = ?";

		int result = -1;

		try {

			result = jdbcTemplate.update(sql, passwordEncoder.encode(newPassword), customer_id);

		} catch (Exception e) {
			e.printStackTrace();

		}

		return result;
	}

	public int updateCustomerAccount(CustomerMemberVo customerMemberVo) throws DataAccessException {
		int result = -1;
		customerMemberVo.setCustomer_pw(passwordEncoder.encode(customerMemberVo.getCustomer_pw()));
		result = sqlSession.update("mapper.customerMember.updateCustomerAccount", customerMemberVo);
		return result;
	}

	public CustomerMemberVo selectCustomers(int customer_no) throws DataAccessException{
		List<CustomerMemberVo> customerMemberVos = new ArrayList<CustomerMemberVo>();
		customerMemberVos = sqlSession.selectList("mapper.customerMember.selectCustomers", customer_no);
		return customerMemberVos.get(0);
	}

	public List<NoticeVo> noticeList() throws DataAccessException{
		List<NoticeVo> noticeVos = new ArrayList<>();
		noticeVos = sqlSession.selectList("mapper.customerMember.noticeList");

		return noticeVos;
	}

	public List<AccountVo> customerList()throws DataAccessException {
		List<AccountVo> accountVos = new ArrayList<>();
		accountVos = sqlSession.selectList("mapper.customerMember.customerList");
		return accountVos;
	}

	public int updateApproval(AccountVo accountVo) throws DataAccessException{
		int result = -1;
		result = sqlSession.update("mapper.customerMember.updateApproval", accountVo);
		return result;
	}

	public AccountVo customerDetail(int customer_no)throws DataAccessException {	
		List<AccountVo> accountDetail  = sqlSession.selectList("mapper.customerMember.customerDetail", customer_no);
		return accountDetail.size()>0?accountDetail.get(0) : null;
		
	}

	public AccountVo userTransfer(int customer_no) {
		List<AccountVo> userTransfer  = sqlSession.selectList("mapper.customerMember.userTransfer", customer_no);
		return userTransfer.size()>0?userTransfer.get(0) : null;
	}

	public List<TransactionVo> transactionList(int customer_no) throws DataAccessException  {
		List<TransactionVo> transactionVos = new ArrayList<>();
		transactionVos = sqlSession.selectList("mapper.customerMember.transactionList", customer_no);
		System.out.println(transactionVos+"DAO");
		return transactionVos;
		
	}

	public List<ExchangeVo> exchangeList(String account_number)  throws DataAccessException {
		List<ExchangeVo> exchangeVos = new ArrayList<>();
		exchangeVos = sqlSession.selectList("mapper.customerMember.exchangeList", account_number);	
		return exchangeVos;
	}

	public List<LoanVo> userLoanList(int customer_no) throws DataAccessException {
		List<LoanVo> loanVos  = sqlSession.selectList("mapper.customerMember.userLoanList", customer_no);
		return loanVos;
	
	}

	public LoanVo customerLoanDetail(LoanVo loanVo)  throws DataAccessException{
		List<LoanVo> loanVos = new ArrayList<>();
		loanVos = sqlSession.selectList("mapper.customerMember.customerLoanDetail", loanVo);	
		return loanVos.size()>0?loanVos.get(0) : null;
	}

	public int loanApprovalUpdate(int loan_no) throws DataAccessException {
		int result = -1;
		result = sqlSession.update("mapper.customerMember.loanApprovalUpdate", loan_no);
		return result;
	}

	public int loanApprovalUpdateNg(int loan_no) throws DataAccessException {
		int result = -1;
		result = sqlSession.update("mapper.customerMember.loanApprovalUpdateNg", loan_no);
		return result;
	}

	public int loanBalanceUpdate(LoanVo loanVo)  throws DataAccessException{
		int result = -1;
		result = sqlSession.update("mapper.customerMember.loanBalanceUpdate", loanVo);
		return result;
	}

	public NoticeVo noticeDetail(int notice_no)  throws DataAccessException{
		List<NoticeVo> noticeDetail  = sqlSession.selectList("mapper.customerMember.noticeDetail", notice_no);
		return noticeDetail.size()>0?noticeDetail.get(0) : null;
	}

	public int noticeInsert(NoticeVo noticeVo) {
		int result = -1;
		result = sqlSession.insert("mapper.customerMember.noticeInsert", noticeVo);
		return result;
	}

	public int noticeDelet(int notice_no) {
		int result = -1;
		result = sqlSession.delete("mapper.customerMember.noticeDelet", notice_no);
		return result;
	}
}
