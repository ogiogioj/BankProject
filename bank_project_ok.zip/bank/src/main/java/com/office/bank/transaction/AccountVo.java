package com.office.bank.transaction;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountVo {

	int account_no;
	String account_number;
	int customer_no;
	int balance; // 내돈
	String open_date;
	int approval;
	String account_pw;

	String customer_id;
	String customer_pw;
	String customer_rrn;
	String first_name;
	String last_name;
	String date_of_birth;
	String address;
	String phone_number;
	String email;
	
	int transaction_no; //오토
	String transaction_type; 
	String amount; // 이체받은돈
	String transaction_date;
	String related_account;
	
	int loan_no;
	String loan_type;
	String loan_amount;
	String loan_date;
	String loan_repayment;
	int loan_approval;
}
