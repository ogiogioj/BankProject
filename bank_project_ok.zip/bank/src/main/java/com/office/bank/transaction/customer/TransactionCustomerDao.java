package com.office.bank.transaction.customer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.office.bank.transaction.AccountVo;
import com.office.bank.transaction.ExchangeVo;
import com.office.bank.transaction.LoanVo;
import com.office.bank.transaction.TransactionVo;
import com.office.bank.transaction.DepositVo;

import org.springframework.security.crypto.password.PasswordEncoder;

@Component

public class TransactionCustomerDao {

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	private SqlSession sqlSession;

	public int insertAccount(AccountVo accountVo) throws DataAccessException {
		int result = -1;
		accountVo.setAccount_pw(passwordEncoder.encode(accountVo.getAccount_pw()));
		result = sqlSession.insert("mapper.transaction.insertAccount", accountVo);
		return result;
	}

	public AccountVo detailAcctontForm(int customer_no) throws DataAccessException  {
		List<AccountVo> accountVos = new ArrayList<>();
		accountVos = sqlSession.selectList("mapper.transaction.detailAcctontForm", customer_no);
		return accountVos.size()>0 ? accountVos.get(0) : null;
	}

	public int loanConfirm(LoanVo loanVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.insert("mapper.transaction.loanConfirm", loanVo);
		return result;
	}

	public  AccountVo transfer(int customer_no) throws DataAccessException  {
		AccountVo accountVo = sqlSession.selectOne("mapper.transaction.transfer", customer_no);
		return accountVo;
				}

	public int createTransferConfirm(TransactionVo transactionVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.insert("mapper.transaction.createTransferConfirm", transactionVo);
		return result;
	}

	public int updateAccountBalance(AccountVo accountVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.update("mapper.transaction.updateAccountBalance", accountVo);
		return result;
	}

	public int minusAccountBalance(AccountVo accountVo) throws DataAccessException {
		System.out.println(accountVo.getAccount_number());
		int result = -1;
		result = sqlSession.update("mapper.transaction.minusAccountBalance", accountVo);
		return result;

	}

	public int createExchangeConfirm(ExchangeVo exchangeVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.insert("mapper.transaction.createExchangeConfirm", exchangeVo);
		return result;
	}

	public int minusExchangeBalance(ExchangeVo exchangeVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.update("mapper.transaction.minusExchangeBalance", exchangeVo);
		return result;
	}

	public int matchAccountPw(AccountVo accountVo) throws DataAccessException  {
		
		List<AccountVo> accountVos = sqlSession.selectList("mapper.transaction.matchAccountPw", accountVo.getAccount_number());
		if (!passwordEncoder.matches(accountVo.getAccount_pw(), accountVos.get(0).getAccount_pw())) {
			accountVos.clear();
		}
		return accountVos.size() > 0 ? 1 : -1;
	}

	public List<TransactionVo> transactionList(int customer_no) throws DataAccessException  {
		List<TransactionVo> transactionVos = new ArrayList<>();
		transactionVos = sqlSession.selectList("mapper.transaction.transactionList", customer_no);
		System.out.println(transactionVos+"DAO");
		return transactionVos;
		
	}

	public List<ExchangeVo> exchangeList(String account_number)  throws DataAccessException {
		List<ExchangeVo> exchangeVos = new ArrayList<>();
		exchangeVos = sqlSession.selectList("mapper.transaction.exchangeList", account_number);
		System.out.println(exchangeVos+"DAO");
		return exchangeVos;
	}

	public int insertdepositTable(TransactionVo transactionVo)throws DataAccessException {
		int result = -1;
		result = sqlSession.insert("mapper.transaction.insertdepositTable", transactionVo);
		return result;
	}

	public int selectBalance(AccountVo accountVo)throws DataAccessException {
		int result = -1;
		result = sqlSession.selectOne("mapper.transaction.selectBalance",accountVo );
		return result;
	}

	public int updateCustomerNo(TransactionVo transactionVo) {
		int result = -1;
		result = sqlSession.update("mapper.transaction.updateCustomerNo",transactionVo );
		return result;
	}

	public List<LoanVo> loanList(int customer_no) {
		List<LoanVo> loanVos = new ArrayList<>();
		loanVos = sqlSession.selectList("mapper.transaction.loanList", customer_no);
		System.out.println(loanVos+"DAO");
		return loanVos;
	}

	public LoanVo LoanDetail(int customer_no) {
		List<LoanVo> loanVos = new ArrayList<>();
		loanVos = sqlSession.selectList("mapper.transaction.LoanDetail", customer_no);
		System.out.println(loanVos+"DAO");
		return loanVos.size() > 0 ? loanVos.get(0) : null;
	}
}
