package com.office.bank.transaction;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TransactionVo {
	int transaction_no; //오토
	String account_number; //계좌번호
	String transaction_type; 
	String amount;
	String transaction_date;
	String related_account;
	int customer_no;
	int transaction_balance;
	int account_no; // 오토 
	
	int deposit_no; //오토
	String deposit_date;
	int deposit_balance;	
	
	int balance;
	String open_date;
	String approval;
	String account_pw;

	String customer_id;
	String customer_pw;
	String customer_rrn;
	String first_name;
	String last_name;
	String date_of_birth;
	String address;
	String phone_number;
	String email;
}
