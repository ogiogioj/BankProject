package com.office.bank.admin.member;

public class AdminMemberController {

}
