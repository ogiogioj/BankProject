package com.office.bank.transaction;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NoticeVo {
	int notice_no;
	String notice_title;
	String notice_content;
	String notice_date;
}
