package com.office.bank.transaction.customer;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.office.bank.transaction.TransactionVo;

import com.office.bank.utils.ExchangeRateUtils;
import com.office.bank.transaction.LoanVo;
import com.office.bank.transaction.PageVo;
import com.office.bank.customer.member.CustomerMemberService;
import com.office.bank.customer.member.CustomerMemberVo;
import com.office.bank.transaction.AccountVo;
import com.office.bank.transaction.DepositVo;
import com.office.bank.transaction.ExchangeVo;

@Controller
@RequestMapping("/transaction/customer")
public class TransactionCustomerContoller {
	@Autowired
	TransactionCustomerService transactionCustomerService;

	@GetMapping("/createAcctontForm")
	public String createAcctontForm() {
		System.out.println("[TransactionCustomerContoller] createAcctontForm()");
		String nextPage = "customer/member/create_account_form";
		return nextPage;
	}

	@PostMapping("/createAccountConfirm")
	public String createAccountConfirm(AccountVo accountVo) {
		String nextPage = "customer/member/create_account_ok";
		int result = transactionCustomerService.createAccountConfirm(accountVo);
		if (result <= 0) {
			nextPage = "customer/member/create_account_ng";
		}
		return nextPage;
	}

	// 상세정보폼
	@GetMapping("/detailAcctontForm")
	public String detailAcctontForm(HttpSession session, Model model) {
		System.out.println("[TransactionCustomerContoller] detailAcctontForm()");

		String nextPage = "customer/account/account_detail_form";

		CustomerMemberVo loginedCustomerMemberVo = (CustomerMemberVo) session.getAttribute("loginedCustomerMemberVo");
		AccountVo accountVo = transactionCustomerService.detailAcctontForm(loginedCustomerMemberVo.getCustomer_no());

		model.addAttribute("accountVo", accountVo);

		return nextPage;
	}

	// ajax 계좌이체상세정보
	@GetMapping("/transferAjax")
	public String transferAjax(HttpSession session, Model model, @RequestParam("defaultValue1") int pageNum,
			@RequestParam("defaultValue2") int pageSize) {

		CustomerMemberVo loginedCustomerMemberVo = (CustomerMemberVo) session.getAttribute("loginedCustomerMemberVo");	
		
		List<TransactionVo> trasactionVos = transactionCustomerService.transactionList(loginedCustomerMemberVo.getCustomer_no());

		
		int total = trasactionVos.size();
		System.out.println(trasactionVos + "배열이넘어오나?");
		System.out.println(total + "계좌이체사이즈");	
		// 유효한 페이지 번호와 페이지 크기를 보장
		pageNum = Math.max(1, pageNum);
		pageSize = Math.max(1, pageSize);
		// fromIndex = 시작인덱스 0~시작 ex) {1.2.3.4.5} 0 = 1 , 1 = 2
		// toIndex = 마지막인덱스 -1 ex){1.2.3.4.5} 4 = 4??
		int fromIndex = (pageNum - 1) * pageSize;
		int toIndex = Math.min(fromIndex + pageSize, total);
		System.out.println(fromIndex + "몇?" + pageSize + "몇?" + toIndex + "몇?");
		// 범위를 벗어나지 않도록 조정
		fromIndex = Math.max(0, fromIndex);
		toIndex = Math.min(total, toIndex);
		model.addAttribute("trasactionVos", trasactionVos);
		List<TransactionVo> pagedTransferList = trasactionVos.subList(fromIndex, toIndex);
		System.out.println(pagedTransferList + "이건뭘까??");
		PageVo pageVo = new PageVo(pageNum, pageSize, total);
		model.addAttribute("trasactionVos", pagedTransferList);
		model.addAttribute("pageVo", pageVo);
		return "customer/account/transfer_table";

	}

	// ajax 환전정보상세정보
	@GetMapping("/exchangeAjax")
	public String exchangeAjax(HttpSession session, Model model, @RequestParam("defaultValue1") int pageNum,
			@RequestParam("defaultValue2") int pageSize) {

		CustomerMemberVo loginedCustomerMemberVo = (CustomerMemberVo) session.getAttribute("loginedCustomerMemberVo");

		AccountVo accountVo = transactionCustomerService.detailAcctontForm(loginedCustomerMemberVo.getCustomer_no());
		List<ExchangeVo> exchangeVos = transactionCustomerService.exchangeList(accountVo.getAccount_number());
		int total = exchangeVos.size();
		System.out.println(total + "환전사이즈");
		pageNum = Math.max(1, pageNum);
		pageSize = Math.max(1, pageSize);

		int fromIndex = (pageNum - 1) * pageSize;
		int toIndex = Math.min(fromIndex + pageSize, total);
		System.out.println(fromIndex + "몇?" + pageSize + "몇?" + toIndex + "몇?");
		// 범위를 벗어나지 않도록 조정
		fromIndex = Math.max(0, fromIndex);
		toIndex = Math.min(total, toIndex);
		model.addAttribute("exchangeVos", exchangeVos);
		List<ExchangeVo> pagedExchangeList = exchangeVos.subList(fromIndex, toIndex);
		PageVo pageVo = new PageVo(pageNum, pageSize, total);
		model.addAttribute("exchangeVos", pagedExchangeList);
		model.addAttribute("pageVo", pageVo);
		return "customer/account/exchange_table";
	}

	// 대출폼
	@GetMapping("/loanForm")
	public String loanForm(HttpSession session, Model model) {
		System.out.println("[TransactionCustomerContoller] loanForm()");
		String nextPage = "customer/account/loan_account_form";
		CustomerMemberVo loginedCustomerMemberVo = (CustomerMemberVo) session.getAttribute("loginedCustomerMemberVo");
		AccountVo accountVo = transactionCustomerService.detailAcctontForm(loginedCustomerMemberVo.getCustomer_no());
		model.addAttribute("accountVo", accountVo);
		return nextPage;

	}

	// 대출상세페이지
	@GetMapping("/loanAjax")
	public String loanAjax(HttpSession session, Model model, @RequestParam("defaultValue1") int pageNum,
			@RequestParam("defaultValue2") int pageSizes) {
		System.out.println("들어왔는가자네");
		CustomerMemberVo loginedCustomerMemberVo = (CustomerMemberVo) session.getAttribute("loginedCustomerMemberVo");
		List<LoanVo> loanVos = transactionCustomerService.loanList(loginedCustomerMemberVo.getCustomer_no());
		int total = loanVos.size();
		System.out.println(total + "대출사이즈");
		pageNum = Math.max(1, pageNum);
		pageSizes = Math.max(1, pageSizes);

		int fromIndex = (pageNum - 1) * pageSizes;
		int toIndex = Math.min(fromIndex + pageSizes, total);
		System.out.println(fromIndex + "몇?" + pageSizes + "몇?" + toIndex + "몇?");
		// 범위를 벗어나지 않도록 조정
		fromIndex = Math.max(0, fromIndex);
		toIndex = Math.min(total, toIndex);
		model.addAttribute("loanVos", loanVos);
		List<LoanVo> pagedExchangeList = loanVos.subList(fromIndex, toIndex);
		PageVo pageVo = new PageVo(pageNum, pageSizes, total);
		model.addAttribute("loanVos", pagedExchangeList);
		model.addAttribute("pageVo", pageVo);
		return "customer/account/loan_table";
	}

	// 환전폼
	@GetMapping("/createExchangeForm")
	public String createExchangeForm(HttpSession session, Model model) {
		System.out.println("[TransactionCustomerContoller] exchangeForm()");
		String nextPage = "customer/account/account_exchange_form";
		CustomerMemberVo loginedCustomerMemberVo = (CustomerMemberVo) session.getAttribute("loginedCustomerMemberVo");
		AccountVo accountVo = transactionCustomerService.detailAcctontForm(loginedCustomerMemberVo.getCustomer_no());
		model.addAttribute("accountVo", accountVo);
		return nextPage;
	}

	// 이체폼
	@GetMapping("/transfer")
	public String transfer(Model model, HttpSession session) {
		System.out.println("[TransactionCustomerContoller] transfer()");
		String nextPage = "customer/account/account_transfer_form";
		CustomerMemberVo loginedCustomerMemberVo = (CustomerMemberVo) session.getAttribute("loginedCustomerMemberVo");
		AccountVo accountVo = transactionCustomerService.transfer(loginedCustomerMemberVo.getCustomer_no());
		model.addAttribute("accountVo", accountVo);
		return nextPage;
	}

	// 대출받기
	@PostMapping("/loanConfirm")
	public String loanConfirm(LoanVo loanVo) {
		String nextPage = "customer/account/loan_list";
		int result = transactionCustomerService.loanConfirm(loanVo);
		if (result <= 0) {
			nextPage = "customer/account/account_loan_ng";
		}
		return nextPage;
	}
	@GetMapping("/loanList")
		public String loanList(Model model, HttpSession session, LoanVo loanvo) {
		CustomerMemberVo loginedCustomerMemberVo = (CustomerMemberVo) session.getAttribute("loginedCustomerMemberVo");
		List<LoanVo> loanvos = transactionCustomerService.loanList(loginedCustomerMemberVo.getCustomer_no());
		model.addAttribute("loanvos", loanvos);
		String nextPage = "customer/account/loan_list";
		return nextPage;
	}
	

	// 이체하기
	@Transactional
	@PostMapping("/createTransferConfirm")
	public String createTransferConfirm(AccountVo accountVo, TransactionVo transactionVo, DepositVo depositVo,
			Model model) {
		String nextPage = "customer/account/account_transfer_ok";

		int result1 = transactionCustomerService.matchAccountPw(accountVo);
		int result2 = transactionCustomerService.minusAccountBalance(accountVo); // 보낸사람 계좌금액 감소
		int result3 = transactionCustomerService.updateAccountBalance(accountVo); // 받은사람 계좌금액 증가

		System.out.println("컨트롤러 계좌잔액" + accountVo.getBalance());
		transactionVo.setTransaction_balance(accountVo.getBalance() - Integer.parseInt(transactionVo.getAmount()));
		int result4 = transactionCustomerService.createTransferConfirm(transactionVo); // 출금내역 테이블
		// depositVo.setDeposit_balance(result4);
		// int result5 = transactionCustomerService.insertdepositTable(transactionVo);
		// // 입금내역 테이블
		int result5 = transactionCustomerService.selectBalance(accountVo);
		transactionVo.setTransaction_balance(result5);
		int result6 = transactionCustomerService.insertdepositTable(transactionVo); // 출금내역 테이블
		if (result6 > 0) {
			System.out.println(result6 + "인서트");
			int resutl7 = transactionCustomerService.updateCustomerNo(transactionVo);
			System.out.println(resutl7 + "회원번호변경");
		}

		System.out.println(result1);
		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result5 + "deposit 테이블인서트되냐?");
		if (result1 <= 0 || result2 <= 0 || result3 <= 0 || result4 <= 0 || result5 <= 0 || result6 <= 0) {
			nextPage = "customer/account/account_transfer_ng";
		}

		return "redirect:/transaction/customer/detailAcctontForm";
	}

	@PostMapping("/exchange/getExchangeRate/{currency}")
	public ResponseEntity<Map<String, BigDecimal>> getExchangeRate(@PathVariable("currency") String currency) {
		System.out.println("실행하니2?");
		BigDecimal exchangeRate = ExchangeRateUtils.getExchangeRate(currency);

		Map<String, BigDecimal> response = new HashMap<>();
		response.put("exchangeRate", exchangeRate);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// 환전하기
	@Transactional
	@PostMapping("/createExchangeConfirm")
	public String createExchangeConfirm(AccountVo accountVo, ExchangeVo exchangeVo) {
		String nextPage = "customer/account/account_exchange_ng";
		int result1 = transactionCustomerService.matchAccountPw(accountVo);
		System.out.println(result1 + "값은?");
		if (result1 > 0) {
			int result3 = transactionCustomerService.minusExchangeBalance(exchangeVo);
			exchangeVo.setExchange_result(accountVo.getBalance() - Integer.parseInt(exchangeVo.getExchange_balance()));
			int result2 = transactionCustomerService.createExchangeConfirm(exchangeVo);
			System.out.println("환전후잔액" + exchangeVo.getExchange_result());
			System.out.println(result1 + "크리에이트");
			System.out.println(result2 + "넘어오는거니 마이너스");
			System.out.println(result3 + "제발좀");
			if (result2 > 0 && result3 > 0) {

				nextPage = "redirect:/transaction/customer/detailAcctontForm";
			}

			return nextPage;
		}
		return nextPage;

	}
	
	@GetMapping("/LoanDetail")
	public String LoanDetail(Model model, HttpSession session, LoanVo loanvo) {
	String nextPage="customer/account/loan_detail_form";
	CustomerMemberVo loginedCustomerMemberVo = (CustomerMemberVo) session.getAttribute("loginedCustomerMemberVo");
	LoanVo loanVos = transactionCustomerService.LoanDetail(loginedCustomerMemberVo.getCustomer_no());
	model.addAttribute("loanVos", loanVos);
		return	nextPage ;
	}

	
}