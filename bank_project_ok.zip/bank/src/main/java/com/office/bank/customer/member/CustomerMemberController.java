package com.office.bank.customer.member;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.office.bank.admin.member.AdminMemberVo;
import com.office.bank.transaction.AccountVo;
import com.office.bank.transaction.ExchangeVo;
import com.office.bank.transaction.LoanVo;
import com.office.bank.transaction.NoticeVo;
import com.office.bank.transaction.PageVo;
import com.office.bank.transaction.TransactionVo;

@Controller
@RequestMapping("/customer/member")
public class CustomerMemberController {
	private static final String customer_no = null;

	@Autowired
	CustomerMemberService customerMemberService;

	@Autowired
	private JavaMailSender mailSender;

	@ResponseBody
	@RequestMapping(value = "/idCheck/{customerid}", method = { RequestMethod.POST, RequestMethod.GET })
	public Map<String, Boolean> idCheck(@PathVariable("customerid") String customer_id) {
//		String a_m_id = map.get("a_m_id");
		System.out.println(customer_id);
		Map<String, Boolean> resultMap = new HashMap<String, Boolean>();
		boolean isMember = customerMemberService.idCheck(customer_id);
		resultMap.put("result", isMember);
		return resultMap;
	}

	/* 이메일 인증 */
	@RequestMapping(value = "/mailCheck", method = RequestMethod.GET)
	@ResponseBody
	public String mailCheckGET(String email) throws Exception {
		System.out.println("이메일 데이터 전송 확인");
		System.out.println("인증번호 : " + email);
		/* 뷰(View)로부터 넘어온 데이터 확인 */
		Random random = new Random();
		int checkNum = random.nextInt(888888) + 111111;
		System.out.println("인증번호" + checkNum);
		String setFrom = "dhrlwjd12@gmail.com";
		String toMail = email;
		String title = "회원가입 인증 이메일 입니다.";
		String content = "홈페이지를 방문해주셔서 감사합니다." + "<br><br>" + "인증 번호는 " + checkNum + "입니다." + "<br>"
				+ "해당 인증번호를 인증번호 확인란에 기입하여 주세요.";
		/*
		 * try {
		 * 
		 * MimeMessage message = mailSender.createMimeMessage(); MimeMessageHelper
		 * helper = new MimeMessageHelper(message, true, "utf-8");
		 * helper.setFrom(setFrom); helper.setTo(toMail); helper.setSubject(title);
		 * helper.setText(content, true); mailSender.send(message);
		 * 
		 * } catch (Exception e) { e.printStackTrace(); }
		 */
		String num = Integer.toString(checkNum);

		return num;

	}

	@GetMapping("/createCustomerForm")
	public String createCustomerForm() {
		System.out.println("[CustomerMemberController] createCustomerForm()");
		String nextPage = "customer/member/create_customer_form";
		return nextPage;
	}

	@PostMapping("/createCustomerConfirm")
	public String createCustomerConfirm(CustomerMemberVo customerMemberVo) {
		String nextPage = "customer/member/create_customer_ok";
		int result = customerMemberService.createCustomerConfirm(customerMemberVo);
		if (result <= 0) {
			nextPage = "customer/member/create_customer_ng";
		}
		return nextPage;
	}

	@GetMapping("/loginForm")
	public String loginForm() {
		String nextPage = "customer/member/login_form";
		return nextPage;
	}

	@GetMapping("/detailForm")
	public String detailForm() {
		String nextPage = "customer/member/customer_detail_form";
		return nextPage;
	}

	@PostMapping("/loginConfirm")
	public String loginConfirm(CustomerMemberVo customerMemberVo, HttpSession session) {
//		String nextPage = "customer/member/login_ok";
		System.out.println(customerMemberVo+"뉴진스");
		CustomerMemberVo loginedCustomerMemberVo = customerMemberService.loginConfirm(customerMemberVo);
		System.out.println(loginedCustomerMemberVo+"와라라라랔랔라칼칼ㅋ");
		if (loginedCustomerMemberVo == null) {
			return "redirect:/customer/member/loginForm";
		} else {
			session.setAttribute("loginedCustomerMemberVo", loginedCustomerMemberVo);
			session.setMaxInactiveInterval(60 * 30); // ���� �ִ� �����ð� 60*30=1800��(30��)
		}
		return "redirect:/";
	}

	@ResponseBody
	@GetMapping("/checkPW")
	public Map<String, Integer> checkPW(@RequestParam("check") String checkPW, HttpSession session) {
//		String nextPage = "customer/member/login_ok";
		CustomerMemberVo loginedCustomerMemberVo = (CustomerMemberVo) session.getAttribute("loginedCustomerMemberVo");
		loginedCustomerMemberVo.setCustomer_pw(checkPW);
		loginedCustomerMemberVo = customerMemberService.loginConfirm(loginedCustomerMemberVo);
		int result = 1;
		if (loginedCustomerMemberVo == null) {
			result = 0;
		}
		Map<String, Integer> map = new HashMap<>();
		map.put("result", result);
		return map;
	}

	@GetMapping("/logoutConfirm")
	public String logoutConfirm(HttpSession session) {
		String nextPage = "redirect:/";
		session.invalidate();
		return nextPage;
	}

	@GetMapping("/findPasswordForm")
	public String findePasswordForm() {
		String nextPage = "customer/member/find_password_form";
		return nextPage;
	}

	@PostMapping("/findPasswordConfirm")
	public String findPasswordConfirm(CustomerMemberVo customerMemberVo) {
		System.out.println(customerMemberVo.getCustomer_id());
		String nextPage = "customer/member/find_password_ok";
		int result = customerMemberService.findPasswordConfirm(customerMemberVo);
		if (result <= 0)
			nextPage = "customer/member/find_password_ng";
		return nextPage;
	}

	@GetMapping("/modifyAccountForm")
	public String modifyAccountForm(HttpSession session) {
		String nextPage = "customer/member/modify_account_form";
		return nextPage;
	}

	@PostMapping("/modifyAccountConfirm")
	public String modifyAccountConfirm(CustomerMemberVo customerMemberVo, HttpSession session) {
		String nextPage = "customer/member/modify_account_ok";
		System.out.println(customerMemberVo.getCustomer_id());
		int result = customerMemberService.modifyAccountConfirm(customerMemberVo);
		if (result > 0) {
			CustomerMemberVo loginedCustomerMemberVo = customerMemberService
					.getLoginedCustomerMemberVo(customerMemberVo.getCustomer_no());
			session.setAttribute("loginedCustomerMemberVo", loginedCustomerMemberVo);
			session.setMaxInactiveInterval(60 * 30);

		} else {
			nextPage = "customer/member/modify_account_ng";

		}
		return nextPage;
	}

	// 공지사항 리스트 뽑아오기
	@GetMapping("/noticeList")
	public String noticeList(NoticeVo noticeVo, Model model) {
		String nextPage = "customer/member/notice_list";
		List<NoticeVo> noticeVos = customerMemberService.noticeList();
		System.out.println(noticeVos + "공지사항");
		model.addAttribute("noticeVos", noticeVos);
		return nextPage;

	}

	// @회원정보 리스트 뽑아오기
	@GetMapping("/customerList")
	public String customerList() {
		String nextPage = "customer/member/customer_member_list";

		return nextPage;
	}

	// @회원정보 리스트 뽑아오기
	@GetMapping("/customerListForm")
	public String customerListForm(AccountVo accountVo, Model model, @RequestParam("pageNumber") int pageNum,
			@RequestParam("pageSize") int pageSize) {
		String nextPage = "customer/member/customer_list_table";
		List<AccountVo> accountVos = customerMemberService.customerList();
		model.addAttribute("accountVos", accountVos);
		int total = accountVos.size();
		System.out.println(accountVos + "리스트?");
		System.out.println(total + "리스트");
		// 유효한 페이지 번호와 페이지 크기를 보장
		pageNum = Math.max(1, pageNum);
		pageSize = Math.max(1, pageSize);
		// fromIndex = 시작인덱스 0~시작 ex) {1.2.3.4.5} 0 = 1 , 1 = 2
		// toIndex = 마지막인덱스 -1 ex){1.2.3.4.5} 4 = 4??
		int fromIndex = (pageNum - 1) * pageSize;
		int toIndex = Math.min(fromIndex + pageSize, total);
		System.out.println(fromIndex + "몇?" + pageSize + "몇?" + toIndex + "몇?");
		// 범위를 벗어나지 않도록 조정
		fromIndex = Math.max(0, fromIndex);
		toIndex = Math.min(total, toIndex);
		model.addAttribute("accountVos", accountVos);
		List<AccountVo> pagedTransferList = accountVos.subList(fromIndex, toIndex);
		System.out.println(pagedTransferList + "이건뭘까??");
		PageVo pageVo = new PageVo(pageNum, pageSize, total);
		model.addAttribute("accountVos", pagedTransferList);
		model.addAttribute("pageVo", pageVo);
		return nextPage;

	}

	@GetMapping("/approval")
	public String approval(@RequestParam("account_no") int account_no, @RequestParam("approval") int approval,
			Model model, AccountVo accountVo) {
		String nextPage = "customer/member/customer_list_table";
		List<AccountVo> accountVos = new ArrayList<>();
		if (approval == 0) {
			accountVo.setApproval(1);
		} else {
			accountVo.setApproval(0);
		}
		int result = customerMemberService.updateApproval(accountVo);
		if (result > 0) {
			accountVos = customerMemberService.customerList();
			int total = accountVos.size();
			List<AccountVo> pagedTransferList = accountVos.subList(0, 5);
			System.out.println(pagedTransferList + "이건뭘까??");
			PageVo pageVo = new PageVo(1, 5, total);
			model.addAttribute("accountVos", pagedTransferList);
			model.addAttribute("pageVo", pageVo);
		} else {
			return "redirect:/customer/member/customerListForm";
		}

		return nextPage;
	}

	// 회원을눌렀을때 회원의 정보가져오기
	@GetMapping("/customerDetail")
	public String customerDetail(@RequestParam("customer_no") int customer_no, Model model, AccountVo accountVo) {

		AccountVo accountDetail = customerMemberService.customerDetail(customer_no);
		model.addAttribute("accountDetail", accountDetail);
		System.out.println(accountDetail + "정보있나?");
		String nextPage = "customer/member/customer_member_deatil_form";
		return nextPage;
	}

	// ajax 계좌이체상세정보
	@GetMapping("/transferAjax")
	public String transferAjax(Model model, @RequestParam("defaultValue1") int pageNum, AccountVo accountVo,
			@RequestParam("defaultValue2") int pageSize, @RequestParam("customer_no") int customer_no) {
		AccountVo accountDetail = customerMemberService.customerDetail(customer_no);
		List<TransactionVo> trasactionVos = customerMemberService.transactionList(accountDetail.getCustomer_no());
		int total = trasactionVos.size();
		System.out.println(trasactionVos + "배열이넘어오나?");
		System.out.println(total + "계좌이체사이즈");
		// 유효한 페이지 번호와 페이지 크기를 보장
		pageNum = Math.max(1, pageNum);
		pageSize = Math.max(1, pageSize);
		// fromIndex = 시작인덱스 0~시작 ex) {1.2.3.4.5} 0 = 1 , 1 = 2
		// toIndex = 마지막인덱스 -1 ex){1.2.3.4.5} 4 = 4??
		int fromIndex = (pageNum - 1) * pageSize;
		int toIndex = Math.min(fromIndex + pageSize, total);
		System.out.println(fromIndex + "몇?" + pageSize + "몇?" + toIndex + "몇?");
		// 범위를 벗어나지 않도록 조정
		fromIndex = Math.max(0, fromIndex);
		toIndex = Math.min(total, toIndex);
		model.addAttribute("trasactionVos", trasactionVos);
		List<TransactionVo> pagedTransferList = trasactionVos.subList(fromIndex, toIndex);
		System.out.println(pagedTransferList + "이건뭘까??");
		PageVo pageVo = new PageVo(pageNum, pageSize, total);
		model.addAttribute("trasactionVos", pagedTransferList);
		model.addAttribute("pageVo", pageVo);
		return "customer/member/transfer_table";

	}

	// ajax 환전정보상세정보
	@GetMapping("/exchangeAjax")
	public String exchangeAjax(HttpSession session, Model model, @RequestParam("defaultValue1") int pageNum,
			@RequestParam("defaultValue2") int pageSize, @RequestParam("customer_no") int customer_no,
			AccountVo accountVo) {

		AccountVo accountDetail = customerMemberService.customerDetail(customer_no);

		System.out.println(accountDetail.getAccount_number() + "유저컨트롤러");
		List<ExchangeVo> exchangeVos = customerMemberService.exchangeList(accountDetail.getAccount_number());
		int total = exchangeVos.size();
		System.out.println(total + "환전사이즈");
		pageNum = Math.max(1, pageNum);
		pageSize = Math.max(1, pageSize);

		int fromIndex = (pageNum - 1) * pageSize;
		int toIndex = Math.min(fromIndex + pageSize, total);
		System.out.println(fromIndex + "몇?" + pageSize + "몇?" + toIndex + "몇?");
		// 범위를 벗어나지 않도록 조정
		fromIndex = Math.max(0, fromIndex);
		toIndex = Math.min(total, toIndex);
		model.addAttribute("exchangeVos", exchangeVos);
		List<ExchangeVo> pagedExchangeList = exchangeVos.subList(fromIndex, toIndex);
		PageVo pageVo = new PageVo(pageNum, pageSize, total);
		model.addAttribute("exchangeVos", pagedExchangeList);
		model.addAttribute("pageVo", pageVo);
		return "customer/member/exchange_table";
	}

	// 회원대출 신청리스트화면
	@GetMapping("/customerLoanlist")
	public String customerLoanlist(@RequestParam("customer_no") int customer_no, Model model, LoanVo loanVo) {
		String nextPage = "customer/member/customer_loan_list";
		/* List<LoanVo> loanVos= customerMemberService.userLoanList(customer_no); */
		model.addAttribute("customer_no", customer_no);
		return nextPage;
	}

	// 회원대출신청리스트Ajax
	@GetMapping("/customerLoanlistAjax")
	public String customerLoanlist(@RequestParam("pageNumber") int pageNum, @RequestParam("pageSize") int pageSize,
			@RequestParam("customer_no") int customer_no, Model model, LoanVo loanVo) {
		String nextPage = "customer/member/customer_loan_list_table";
		List<LoanVo> loanVos = customerMemberService.userLoanList(customer_no);
		int total = loanVos.size();
		System.out.println(total + "대출신청갯수");
		pageNum = Math.max(1, pageNum);
		pageSize = Math.max(1, pageSize);
		int fromIndex = (pageNum - 1) * pageSize;
		int toIndex = Math.min(fromIndex + pageSize, total);
		System.out.println(fromIndex + "몇?" + pageSize + "몇?" + toIndex + "몇?");
		// 범위를 벗어나지 않도록 조정
		fromIndex = Math.max(0, fromIndex);
		toIndex = Math.min(total, toIndex);
		model.addAttribute("loanVos", loanVos);
		List<LoanVo> pagedExchangeList = loanVos.subList(fromIndex, toIndex);
		PageVo pageVo = new PageVo(pageNum, pageSize, total);
		model.addAttribute("loanVos", pagedExchangeList);
		model.addAttribute("pageVo", pageVo);
		return nextPage;
	}

	// 회원의 대출작성폼보이기
	@GetMapping("/customerLoanDetail")
	public String customerLoanDetail(@RequestParam("loan_no") int loan_no, @RequestParam("customer_no") int customer_no,
			Model model, LoanVo loanVo) {
		String nextPage = "customer/member/customer_loan_detail_form";
		loanVo.setLoan_no(loan_no);
		loanVo.setCustomer_no(customer_no);

		LoanVo loanVos = customerMemberService.customerLoanDetail(loanVo);
		model.addAttribute("loanVos", loanVos);
		return nextPage;
	}

	// 대출승인
	@Transactional
	@GetMapping("/loanOk")
	public String loanOk(@RequestParam("loan_no") int loan_no, @RequestParam("customer_no") int customer_no,
			LoanVo loanVo, Model model) {

		int result = customerMemberService.loanApprovalUpdate(loan_no);
		loanVo.setCustomer_no(customer_no);

		loanVo.setLoan_no(loan_no);
		int result2 = customerMemberService.loanBalanceUpdate(loanVo);

		if (result <= 0 || result2 <= 0) {

		}
		return "redirect:/customer/member/customerLoanlist?customer_no=" + customer_no;
	}

	// 대출거절
	@GetMapping("/loanNg")
	public String loanNg(@RequestParam("loan_no") int loan_no, @RequestParam("customer_no") int customer_no,
			LoanVo loanVo, Model model) {

		int result = customerMemberService.loanApprovalUpdateNg(loan_no);
		if (result <= 0) {

		}
		return "redirect:/customer/member/customerLoanlist?customer_no=" + customer_no;
	}

	// 게시판 작성폼
	@GetMapping("/noticeConfirm")
	public String noticeConfirm() {
		String nextPage = "customer/member/notice_form";
		return nextPage;
	}

	// 공지사항Ajax
	@GetMapping("/noticeAjax")
	public String noticeAjax(@RequestParam("pageNum") int pageNum, @RequestParam("pageSizes") int pageSize, Model model,
			NoticeVo noticeVo) {
		String nextPage = "customer/member/notice_list_table";
		List<NoticeVo> noticeVos = customerMemberService.noticeList();
		int total = noticeVos.size();
		System.out.println(total + "공지사항게시글수");
		pageNum = Math.max(1, pageNum);
		pageSize = Math.max(1, pageSize);
		int fromIndex = (pageNum - 1) * pageSize;
		int toIndex = Math.min(fromIndex + pageSize, total);
		System.out.println(fromIndex + "몇?" + pageSize + "몇?" + toIndex + "몇?");
		// 범위를 벗어나지 않도록 조정
		fromIndex = Math.max(0, fromIndex);
		toIndex = Math.min(total, toIndex);
		System.out.println(noticeVos + "와라라라라랄");
		List<NoticeVo> pagedExchangeList = noticeVos.subList(fromIndex, toIndex);
		PageVo pageVo = new PageVo(pageNum, pageSize, total);
		model.addAttribute("noticeVos", pagedExchangeList);
		System.out.println(pagedExchangeList + "레스기릿!");
		model.addAttribute("pageVo", pageVo);
		return nextPage;

	}

	// 게시판 자세히보기
	@GetMapping("/noticeDetail")
	public String noticeDetail(Model model, NoticeVo noticeVo,@RequestParam("notice_no") int notice_no) {
		String nextPage = "customer/member/notice_detail";
		NoticeVo noticeVos = customerMemberService.noticeDetail(notice_no);
		model.addAttribute("noticeVos", noticeVos);
		return nextPage;
		
	}

	@PostMapping("/noticeInsert")
	public String noticeInsert(NoticeVo noticeVo) {

		int result = customerMemberService.noticeInsert(noticeVo);
		if (result <= 0) {

		}

		return "redirect:/customer/member/noticeList";
	}
	
	@GetMapping("/noticeDelet")
	public String noticeDelet(@RequestParam("notice_no") int notice_no, Model model) {
		
		String nextPage= "customer/member/notice_list_table";
		List<NoticeVo> noticeVos  = new ArrayList<>();
		int result =customerMemberService.noticeDelet(notice_no);
		 if(result >=0) {
			noticeVos = customerMemberService.noticeList();
			model.addAttribute("noticeVos", noticeVos);
		 }
		return nextPage;
	}
}
