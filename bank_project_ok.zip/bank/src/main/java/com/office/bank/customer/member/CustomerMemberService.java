package com.office.bank.customer.member;

import java.security.SecureRandom;
import java.util.Date;
import java.util.List;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

import com.office.bank.transaction.AccountVo;
import com.office.bank.transaction.ExchangeVo;
import com.office.bank.transaction.LoanVo;
import com.office.bank.transaction.NoticeVo;
import com.office.bank.transaction.TransactionVo;

@Service
public class CustomerMemberService {

	final static public int BANK_CUSTOMER_ALREADY_EXIST = 0;
	final static public int BANK_CUSTOMER_CREATE_SUCCESS = 1;
	final static public int BANK_CUSTOMER_CREATE_FAIL = -1;

	@Autowired
	CustomerMemberDao customerMemberDao;

	@Autowired
	JavaMailSenderImpl javaMailSenderImpl;

	public boolean idCheck(String customer_id) {
		return customerMemberDao.isCustomerMember(customer_id);
	}

	public int createCustomerConfirm(CustomerMemberVo CustomerMemberVo) {
		boolean isMember = customerMemberDao.isCustomerMember(CustomerMemberVo.getCustomer_id());
		if (!isMember) {
			int result = customerMemberDao.insertCustomer(CustomerMemberVo);
			if (result > 0) {
				return BANK_CUSTOMER_CREATE_SUCCESS;
			} else {
				return BANK_CUSTOMER_CREATE_FAIL;
			}
		} else {
			return BANK_CUSTOMER_ALREADY_EXIST;
		}
	}

	public CustomerMemberVo loginConfirm(CustomerMemberVo customerMemberVo) {
		CustomerMemberVo loginedCustomerMemberVo = customerMemberDao.selectAdmin(customerMemberVo);
		System.out.println(loginedCustomerMemberVo+"서비스");
		return loginedCustomerMemberVo;
	}

	public int findPasswordConfirm(CustomerMemberVo customerMemberVo) {
		CustomerMemberVo selectedCustomerMemberVo = customerMemberDao.selectAdmins(customerMemberVo);
		System.out.println(selectedCustomerMemberVo);
		int result = 0;
		if (selectedCustomerMemberVo != null) {
			String newPassword = createNewPassword();
			System.out.println(newPassword);
			result = customerMemberDao.updatePassword(customerMemberVo.getCustomer_id(), newPassword);
			if (result > 0)
				sendNewPasswordByMail(customerMemberVo.getEmail(), newPassword);
		}
		return result;
	}

	private String createNewPassword() {
		char[] chars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g',
				'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
		StringBuffer stringBuffer = new StringBuffer();
		SecureRandom secureRandom = new SecureRandom();
		secureRandom.setSeed(new Date().getTime());

		int index = 0;
		int length = chars.length;
		for (int i = 0; i < 8; i++) {
			index = secureRandom.nextInt(length);

			if (index % 2 == 0)
				stringBuffer.append(String.valueOf(chars[index]).toUpperCase());
			else
				stringBuffer.append(String.valueOf(chars[index]).toLowerCase());

		}
		System.out.println("[CustomerMemberService] NEW PASSWORD: " + stringBuffer.toString());
		return stringBuffer.toString();
	}

	private void sendNewPasswordByMail(final String toMailAddr, final String newPassword) {
		final MimeMessagePreparator mimeMessagePreparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				final MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
				mimeMessageHelper.setTo(toMailAddr);
				mimeMessageHelper.setSubject("새로운비밀번호.");
				mimeMessageHelper.setText("새로운비밀번호" + newPassword, true);
			}
		};
		javaMailSenderImpl.send(mimeMessagePreparator);
	}

	public int modifyAccountConfirm(CustomerMemberVo customerMemberVo) {
		return customerMemberDao.updateCustomerAccount(customerMemberVo);
	}

	public CustomerMemberVo getLoginedCustomerMemberVo(int customer_no) {
		return customerMemberDao.selectCustomers(customer_no);
	}

	public List<NoticeVo> noticeList() {
		return customerMemberDao.noticeList();
	}

	public List<AccountVo> customerList() {
		return customerMemberDao.customerList();
	}

	public int updateApproval(AccountVo accountVo) {
		return customerMemberDao.updateApproval(accountVo);
	}

	public AccountVo customerDetail(int customer_no) {
		return customerMemberDao.customerDetail(customer_no);
	}

	public AccountVo userTransfer(int customer_no) {
		return customerMemberDao.userTransfer(customer_no);
	}
	
	public List<TransactionVo> transactionList(int customer_no) {
		return customerMemberDao.transactionList(customer_no);
	}



	public List<ExchangeVo> exchangeList(String account_number) {
		return customerMemberDao.exchangeList(account_number);
	}

	public 	List<LoanVo> userLoanList(int customer_no) {
		return customerMemberDao.userLoanList(customer_no);
	}

	public  LoanVo customerLoanDetail(LoanVo loanVo) {
		return customerMemberDao.customerLoanDetail(loanVo);
	}

	public int loanApprovalUpdate(int loan_no) {
		return customerMemberDao.loanApprovalUpdate(loan_no);
	}

	public int loanApprovalUpdateNg(int loan_no) {
		return customerMemberDao.loanApprovalUpdateNg(loan_no);
	}

	public int loanBalanceUpdate(LoanVo loanVo) {
		return customerMemberDao.loanBalanceUpdate(loanVo);
	}

	public NoticeVo noticeDetail(int  notice_no) {
		return customerMemberDao.noticeDetail(notice_no);
	}

	public int noticeInsert(NoticeVo noticeVo) {
		return customerMemberDao.noticeInsert(noticeVo);
	}

	public int noticeDelet(int notice_no) {
		return customerMemberDao.noticeDelet(notice_no);
		
	}
	

}
