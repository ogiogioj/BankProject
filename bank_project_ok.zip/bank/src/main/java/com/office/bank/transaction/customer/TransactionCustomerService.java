package com.office.bank.transaction.customer;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.office.bank.customer.member.CustomerMemberVo;
import com.office.bank.transaction.AccountVo;
import com.office.bank.transaction.ExchangeVo;
import com.office.bank.transaction.LoanVo;
import com.office.bank.transaction.TransactionVo;
import com.office.bank.transaction.DepositVo;

@Service
public class TransactionCustomerService {

	@Autowired
	TransactionCustomerDao transactionCustomerDao;

	public int createAccountConfirm(AccountVo accountVo) {

		Random random = new Random();

		StringBuilder randomNumber = new StringBuilder(12);
		for (int i = 0; i < 12; i++) {
			int number = random.nextInt(10);
			randomNumber.append(number);
		}
		accountVo.setAccount_number(randomNumber.toString());

		return transactionCustomerDao.insertAccount(accountVo);

	}

	public AccountVo detailAcctontForm(int customer_no) {

		return transactionCustomerDao.detailAcctontForm(customer_no);
	}

	public int loanConfirm(LoanVo loanVo) {
		 return transactionCustomerDao.loanConfirm(loanVo);
				 
	}


	public AccountVo transfer(int customer_no) {
		return transactionCustomerDao.transfer(customer_no);
	}

	public int createTransferConfirm(TransactionVo transactionVo) {
		System.out.println("실행돼?");
		return transactionCustomerDao.createTransferConfirm(transactionVo);
	}

	public int updateAccountBalance(AccountVo accountVo) {
		System.out.println("실행돼2?");
		return transactionCustomerDao.updateAccountBalance(accountVo);
	}

	public int minusAccountBalance(AccountVo accountVo) {
		System.out.println("실행돼3?");
		
		return transactionCustomerDao.minusAccountBalance(accountVo);
	}



	public int createExchangeConfirm(ExchangeVo exchangeVo) {
		// TODO Auto-generated method stub
		return transactionCustomerDao.createExchangeConfirm(exchangeVo);
	}

	public int minusExchangeBalance(ExchangeVo exchangeVo) {
		// TODO Auto-generated method stub
		return  transactionCustomerDao.minusExchangeBalance(exchangeVo);
	}

	public int matchAccountPw(AccountVo accountVo) {
		
		return transactionCustomerDao.matchAccountPw(accountVo);
	}

	public List<TransactionVo> transactionList(int customer_no) {
		return transactionCustomerDao.transactionList(customer_no);
	}



	public List<ExchangeVo> exchangeList(String account_number) {
		return transactionCustomerDao.exchangeList(account_number);
	}

	public int insertdepositTable(TransactionVo transactionVo) {
		
		return transactionCustomerDao.insertdepositTable(transactionVo);
	}

	public int selectBalance(AccountVo accountVo) {
		return transactionCustomerDao.selectBalance(accountVo);
	}

	public int updateCustomerNo(TransactionVo transactionVo) {
		return transactionCustomerDao.updateCustomerNo(transactionVo);
	}

	public List<LoanVo> loanList(int customer_no) {
		return transactionCustomerDao.loanList(customer_no);
	}

	public LoanVo LoanDetail(int customer_no) {
		return transactionCustomerDao.LoanDetail(customer_no);
	}

	

	
}