package com.office.bank.customer.member;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class CustomerMemberVo {
	int customer_no;
	String customer_id;
	String customer_pw;
	String customer_rrn;
	String first_name;
	String last_name;
	String date_of_birth;
	String address;
	String phone_number;
	String email;
	
	
	int loan_no;
	
	String account_number;
	String loan_type;
	String loan_amount;
	String loan_repayment;

	int account_no;
	int balance;
	String open_date;
	String approval;

	
	
	
	
	
	
}
